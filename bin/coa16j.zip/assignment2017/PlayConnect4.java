/**
 * PlayConnect4 Class
 * 
 * Class that defines instances of all other classes and links them together in one game
 */
package assignment2017;

import assignment2017.codeprovided.*;

public class PlayConnect4 {
    //Where all the magic takes place
    public static void main(String[] args) {
        //Game State
        Connect4GameState gameState = new MyGameState();

        //Players
        Connect4Player red = new RandomPlayer();
        Connect4Player yellow = new KeyboardPlayer();
        
        //Console Display interface
        Connect4ConsoleDisplay display = new Connect4ConsoleDisplay(gameState);

        //Game
        Connect4 game = new Connect4(gameState, red, yellow, display);
        
        //Let the fun begin
        game.play();
    }
}
